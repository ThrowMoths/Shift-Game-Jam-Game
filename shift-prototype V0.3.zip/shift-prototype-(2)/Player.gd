extends CharacterBody2D


const SPEED = 800.0
const JUMP_VELOCITY = -400.0
var shiftMode="1"
var attackDelay:=0.0
var health:=100.0
var maxHealth:=100.0
@onready var testAttack:=preload("res://Player Attack.tscn")
@onready var waterAttack:=preload("res://Holy Water Bottle.tscn")
@onready var meleeAttack:=preload("res://Player Melee Attack.tscn")
func _ready() -> void:
	switch_mode("1")

func _physics_process(delta: float) -> void:
	attackDelay-=delta
	var direction := Vector2(Input.get_axis("ui_left", "ui_right"),Input.get_axis("ui_up","ui_down")).normalized()
	if direction:
		velocity = direction * SPEED
	else:
		velocity *=0

	move_and_slide()

	if Input.is_action_just_pressed("Shift"):
		match shiftMode:
			"1":
				switch_mode("2")
			"2":
				switch_mode("3")
			"3":
				switch_mode("1")
	if Input.is_action_pressed("Left Click") and attackDelay<=0:
		attack()
	
	if Input.is_action_just_pressed("1"):
		switch_mode("1")
	if Input.is_action_just_pressed("2"):
		switch_mode("2")
	if Input.is_action_just_pressed("3"):
		switch_mode("3")
		
	
func switch_mode(newMode):
	match newMode:
		"1":
			shiftMode="1"
			$Sprite2D.texture=load("res://icon.svg")
			
			modulate=Color(1,0,0)
		"2":
			shiftMode="2"
			$Sprite2D.texture=load("res://icon.svg")
			
			modulate=Color(0,1,0)
		"3":
			shiftMode="3"
			$Sprite2D.texture=load("res://icon.svg")
			modulate=Color(0,0,1)
func attack():
	match shiftMode:
		"1":
			attackDelay=0.5
			var newAttack:=meleeAttack.instantiate()
			newAttack.rotation=get_angle_to(get_global_mouse_position())
			newAttack.type=shiftMode
			get_tree().current_scene.add_child(newAttack)
			newAttack.position=position
			
		"2":
			attackDelay=1.0
			var newAttack:=waterAttack.instantiate()
			newAttack.angle=get_angle_to(get_global_mouse_position())
			newAttack.type=shiftMode
			get_tree().current_scene.add_child(newAttack)
			newAttack.position=position
			
			
		"3":
			attackDelay=0.1
			var newAttack:=testAttack.instantiate()
			newAttack.angle=get_angle_to(get_global_mouse_position())
			newAttack.type=shiftMode
			get_tree().current_scene.add_child(newAttack)
			newAttack.position=position

func take_damage(damage):
	health-=damage
	if health<=0:
		if get_tree():
			get_tree().reload_current_scene()
	else:
		get_tree().current_scene.damage_taken()

func ability():
	match shiftMode:
		"1":
			pass
		"2":
			pass
		"3":
			pass
